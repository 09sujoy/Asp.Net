﻿namespace NewsB.Controllers
{
    internal class NewsList
    {
    }
}